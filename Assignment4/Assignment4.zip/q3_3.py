import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

from Assignment4_starter import corrupt_labels, repair_labels

# same data, split, and scaling as 3.1
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00236/seeds_dataset.txt"
seeds = pd.read_csv(url, sep=r"\s+", header=None)
X = seeds.iloc[:, 0:7].to_numpy()
y = seeds[7].to_numpy()  # 1=Kama, 2=Rosa, 3=Canadian

X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4, stratify=y, random_state=0)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=0)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

C = 10
gamma = 1

settings = [
    ("clean", None),
    ("symmetric 20%", {"type": "symmetric", "rate": 0.2}),
    ("symmetric 40%", {"type": "symmetric", "rate": 0.4}),
    ("Kama -> Canadian 30%", {"type": "asymmetric", "rate": 0.3, "from": 1, "to": 3}),
    ("Kama -> Canadian 60%", {"type": "asymmetric", "rate": 0.6, "from": 1, "to": 3}),
]
n_seeds = 10


def evaluate(y_train_used):
    model = SVC(kernel="rbf", C=C, gamma=gamma)
    model.fit(X_train, y_train_used)
    y_pred = model.predict(X_test)
    return accuracy_score(y_test, y_pred), f1_score(y_test, y_pred, average="macro")


for name, config in settings:
    noisy_acc = []
    noisy_f1 = []
    repaired_acc = []
    repaired_f1 = []
    wrong_before = []
    wrong_after = []

    for seed in range(n_seeds):
        if config is None:
            y_noisy = y_train.copy()
        else:
            y_noisy = corrupt_labels(y_train, config, random_state=seed)
        y_repaired = repair_labels(X_train, y_noisy, k=10, threshold=0.7)

        acc, f1 = evaluate(y_noisy)
        noisy_acc.append(acc)
        noisy_f1.append(f1)
        acc, f1 = evaluate(y_repaired)
        repaired_acc.append(acc)
        repaired_f1.append(f1)

        wrong_before.append(np.sum(y_noisy != y_train))
        wrong_after.append(np.sum(y_repaired != y_train))

    print(name)
    print("  wrong labels  before:", np.mean(wrong_before), " after:", np.mean(wrong_after))
    print("  noisy     acc", round(np.mean(noisy_acc), 3), "+-", round(np.std(noisy_acc), 3),
          "  F1", round(np.mean(noisy_f1), 3), "+-", round(np.std(noisy_f1), 3))
    print("  repaired  acc", round(np.mean(repaired_acc), 3), "+-", round(np.std(repaired_acc), 3),
          "  F1", round(np.mean(repaired_f1), 3), "+-", round(np.std(repaired_f1), 3))
