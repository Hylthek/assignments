import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

from Assignment4_starter import kmeans

# load seeds and standardize
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00236/seeds_dataset.txt"
names = ["area", "perimeter", "compactness", "length", "width", "asymmetry", "groove"]
seeds = pd.read_csv(url, sep=r"\s+", header=None)
X_raw = seeds.iloc[:, 0:7].to_numpy()
variety = seeds[7].map({1: "Kama", 2: "Rosa", 3: "Canadian"}).to_numpy()
X = (X_raw - X_raw.mean(axis=0)) / X_raw.std(axis=0)

# K = 3, best of 20 runs
best_inertia = None
for seed in range(20):
    centroids, assignments, inertia = kmeans(X, 3, random_state=seed)
    if best_inertia is None or inertia < best_inertia:
        best_inertia = inertia
        best_centroids = centroids
        best_assignments = assignments

# cluster means in original units
cluster_means = pd.DataFrame(X_raw, columns=names).groupby(best_assignments).mean()
print(cluster_means.round(2))
print(pd.crosstab(best_assignments, variety))

# ambiguous points: second-closest centroid is almost as close as the closest
distances = np.zeros((X.shape[0], 3))
for j in range(3):
    distances[:, j] = np.sqrt(np.sum((X - best_centroids[j]) ** 2, axis=1))
sorted_distances = np.sort(distances, axis=1)
ratio = sorted_distances[:, 0] / sorted_distances[:, 1]
ambiguous = ratio > 0.8
print("ambiguous points:", np.sum(ambiguous))

# PCA to 2D, for plotting only
pca = PCA(n_components=2)
X_2d = pca.fit_transform(X)
centroids_2d = pca.transform(best_centroids)
print("explained variance:", pca.explained_variance_ratio_.round(3))

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

for j in range(3):
    in_cluster = best_assignments == j
    axes[0].scatter(X_2d[in_cluster, 0], X_2d[in_cluster, 1], s=15, label="cluster " + str(j))
axes[0].scatter(X_2d[ambiguous, 0], X_2d[ambiguous, 1], s=60, facecolors="none", edgecolors="black", label="ambiguous")
axes[0].scatter(centroids_2d[:, 0], centroids_2d[:, 1], marker="X", s=150, c="black", label="centroid")
axes[0].set_title("K-means clusters (K=3)")

for v in ["Kama", "Rosa", "Canadian"]:
    is_variety = variety == v
    axes[1].scatter(X_2d[is_variety, 0], X_2d[is_variety, 1], s=15, label=v)
axes[1].set_title("True variety (not used for fitting)")

for ax in axes:
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.legend()
plt.tight_layout()
plt.savefig("q2_4_clusters.png", dpi=150)
