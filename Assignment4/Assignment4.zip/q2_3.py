import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import silhouette_score, adjusted_rand_score

from Assignment4_starter import kmeans

# load seeds and standardize
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00236/seeds_dataset.txt"
seeds = pd.read_csv(url, sep=r"\s+", header=None)
X = seeds.iloc[:, 0:7].to_numpy()
X = (X - X.mean(axis=0)) / X.std(axis=0)

k_values = [2, 3, 4, 5, 6, 7]
n_runs = 20

wcss = []
silhouettes = []
stabilities = []

for k in k_values:
    # run from several random initializations, keep the best (lowest WCSS)
    all_assignments = []
    best_inertia = None
    best_assignments = None
    for seed in range(n_runs):
        centroids, assignments, inertia = kmeans(X, k, random_state=seed)
        all_assignments.append(assignments)
        if best_inertia is None or inertia < best_inertia:
            best_inertia = inertia
            best_assignments = assignments

    # stability: average agreement (ARI) between every pair of runs
    scores = []
    for a in range(n_runs):
        for b in range(a + 1, n_runs):
            scores.append(adjusted_rand_score(all_assignments[a], all_assignments[b]))

    wcss.append(best_inertia)
    silhouettes.append(silhouette_score(X, best_assignments))
    stabilities.append(np.mean(scores))

print("K   WCSS     silhouette  stability")
for i in range(len(k_values)):
    print(k_values[i], round(wcss[i], 1), round(silhouettes[i], 3), round(stabilities[i], 3))

fig, axes = plt.subplots(1, 3, figsize=(12, 3.5))
axes[0].plot(k_values, wcss, "o-")
axes[0].set_title("WCSS")
axes[1].plot(k_values, silhouettes, "o-")
axes[1].set_title("Silhouette")
axes[2].plot(k_values, stabilities, "o-")
axes[2].set_title("Stability (mean pairwise ARI)")
for ax in axes:
    ax.set_xlabel("K")
plt.tight_layout()
plt.savefig("q2_3_choose_k.png", dpi=150)
