import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

# load seeds
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00236/seeds_dataset.txt"
seeds = pd.read_csv(url, sep=r"\s+", header=None)
X = seeds.iloc[:, 0:7].to_numpy()
y = seeds[7].to_numpy()  # 1=Kama, 2=Rosa, 3=Canadian

# 60/20/20 split, stratified so each split has equal class counts
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4, stratify=y, random_state=0)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=0)

# scale using training data only
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)
X_test = scaler.transform(X_test)

# tune C and gamma on the validation set
C_values = [0.1, 1, 10, 100]
gamma_values = [0.01, 0.1, 1, 10]

best_score = -1
for C in C_values:
    for gamma in gamma_values:
        model = SVC(kernel="rbf", C=C, gamma=gamma)
        model.fit(X_train, y_train)
        score = f1_score(y_val, model.predict(X_val), average="macro")
        print("C =", C, "gamma =", gamma, "val macro F1 =", round(score, 3))
        if score > best_score:
            best_score = score
            best_C = C
            best_gamma = gamma

print("best: C =", best_C, "gamma =", best_gamma, "val macro F1 =", round(best_score, 3))

# retrain on train only with best settings, evaluate once on test
model = SVC(kernel="rbf", C=best_C, gamma=best_gamma)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print("test accuracy =", round(accuracy_score(y_test, y_pred), 3))
print("test macro F1 =", round(f1_score(y_test, y_pred, average="macro"), 3))
