# Q1 EM for GMM

Consider a Gaussian mixture model

$$
p(x;\theta) = \sum_{k=1}^{K} \pi_k\,\mathcal{N}(x;\mu_k,\Sigma_k),
$$

where $\pi_k \geq 0$ and $\sum_{k=1}^{K}\pi_k=1$.

## 1.1 E-step derivation (8 points)

Derive the posterior responsibility

$$
r_{ik}=P(z_i=k\mid x_i,\theta)
$$

and show that

$$
r_{ik}=\frac{\pi_k\mathcal{N}(x_i;\mu_k,\Sigma_k)}
{\sum_{j=1}^{K}\pi_j\mathcal{N}(x_i;\mu_j,\Sigma_j)}.
$$

Your derivation should make clear where Bayes' rule and the mixture-model assumptions are used.

## 1.1 solution

$$r_{ik} = P(z_i=k \mid x_i,\theta)$$

Use Bayes' rule.

$$r_{ik} = \frac{p(x_i \mid z_i = k,\theta) P(z_i=k \mid \theta)}{p(x_i \mid \theta)}$$

Substitute prior $P(z_i = k \mid \theta) = \pi_k$.

Substitute likelihood $p(x_i \mid z_i = k, \theta) = \mathcal{N}(x_i;\mu_k,\Sigma_k)$.

These are GMM assumptions about the prior and likelihood.

$$r_{ik} = \frac{\mathcal{N}(x_i;\mu_k,\Sigma_k) \pi_k}{p(x_i \mid \theta)}$$

Use the law of total probability to rewrite the denominator.

$$p(x_i \mid \theta) = \sum_{j=1}^K p(x_i, z_i=j \mid \theta)$$

$$= \sum_{j=1}^K P(z_i=j \mid \theta)\,p(x_i \mid z_i=j,\theta)$$

$$= \sum_{j=1}^K \pi_j\,\mathcal{N}(x_i;\mu_j,\Sigma_j)$$

Substitute.

$$\boxed{r_{ik} = \frac{\pi_k\,\mathcal{N}(x_i;\mu_k,\Sigma_k)}{\sum_{j}\pi_j\,\mathcal{N}(x_i;\mu_j,\Sigma_j)}}$$

## 1.2 M-step derivation (12 points)

Starting from the expected complete-data log likelihood, derive the M-step updates for

- $\mu_k$, and
- $\pi_k$.

You do not need to derive the covariance update.

For each major step, briefly identify the mathematical idea being used (for example: expectation, independence of observations, derivative of a sum, Lagrange multiplier, first-order optimality condition).

## 1.2 solution

Get the complete data likelihood, $p(X,Z;\theta)$.
Take its expectation over $z$'s.
Then maximize for each parameter.

$$p(x_i, z_i=k;\theta) = \pi_k \mathcal{N}(x_i;\mu_k,\Sigma_k)$$

let $z_{ik} = 1$ when $z_i = k$, else $0$

$$p(x_i, z_i;\theta) = \prod_{k=1}^K [\pi_k\,\mathcal{N}(x_i;\mu_k,\Sigma_k)]^{z_{ik}}$$

Since every (x_i,z_i) is iid (independent and identically sampled), the likelihood of all the data points is just the product of each datapoint's likelihood.

$$p(X, Z;\theta) = \prod_{i=1}^{N}\prod_{k=1}^K [\pi_k\,\mathcal{N}(x_i;\mu_k,\Sigma_k)]^{z_{ik}}$$

Take the log.

$$\log p(X, Z;\theta) = \sum_{i=1}^{N}\sum_{k=1}^K z_{ik}[\log\pi_k + \log\mathcal{N}(x_i;\mu_k,\Sigma_k)]$$

We don't know $z_{ik}$ so we can't maximize this directly.

Instead, take the expectation over $Z$.

Expectation is linear so $E_Z[\ldots \sum \sum z_{ik}[\ldots]] = \sum\sum E_Z[z_{ik}]\ldots$.

$E_Z[z_{ik}]$ is the posterior calculated in the E-step $r_{ik}$

$$E_Z[\log p(X, Z;\theta)] = \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}[\log\pi_k + \log\mathcal{N}(x_i;\mu_k,\Sigma_k)]$$

let $Q = E_Z[\log p(X,Z;\theta)]$ we want to maximize this value by changing $\mu_{1\ldots K}$ and $\pi_{1\ldots K}$.

Take the gradients w.r.t. $\mu_k$ and $\pi_k$ for any $k$

Find $\nabla_{\mu_k}Q$

$$\nabla_{\mu_k}Q = \nabla_{\mu_k} \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}[\log\pi_k + \log\mathcal{N}(x_i;\mu_k,\Sigma_k)]$$

substitute $\log \mathcal{N}(x_i;\mu_k,\Sigma_k)$ for $-\tfrac12 (x_i-\mu_k)^T\Sigma_k^{-1}(x_i-\mu_k) - \tfrac12\log|\Sigma_k| - \tfrac d2 \log 2\pi$

$$\nabla_{\mu_k}Q = \nabla_{\mu_k} \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}[\log\pi_k - \tfrac12 (x_i-\mu_k)^T\Sigma_k^{-1}(x_i-\mu_k) - \tfrac12\log|\Sigma_k| - \tfrac d2 \log 2\pi]$$

Remove terms that don't contain $\mu_k$

$$\nabla_{\mu_k}Q = \nabla_{\mu_k} \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}[ -\tfrac12 (x_i-\mu_k)^T\Sigma_k^{-1}(x_i-\mu_k)]$$

Remove terms of $\sum_{k=1}^K$ that don't contain $\mu_k$. Only cluster $k$'s term depends on $\mu_k$, so the sum over all clusters collapses to that one term.


$$\nabla_{\mu_k}Q = \nabla_{\mu_k} \sum_{i=1}^{N} r_{ik}[ -\tfrac12 (x_i-\mu_k)^T\Sigma_k^{-1}(x_i-\mu_k)]$$

Apply "quadratic form gradient", $\nabla_u(u^T A u) = 2Au$

$$\nabla_{\mu_k}Q = \sum_{i=1}^{N} r_{ik}\,\Sigma_k^{-1}(x_i-\mu_k)$$

Set to 0

$$\sum_{i=1}^{N} r_{ik}\,\Sigma_k^{-1}(x_i-\mu_k) = 0$$
$$\Sigma_k^{-1} \sum_{i=1}^{N} r_{ik}(x_i-\mu_k) = 0$$
$$\sum_{i=1}^{N} r_{ik}(x_i-\mu_k) = 0$$
$$\sum_{i=1}^{N} r_{ik}x_i - \mu_k\sum_{i=1}^{N} r_{ik} = 0$$
$$\boxed{\mu_k = \frac{\sum_{i=1}^{N} r_{ik}x_i}{\sum_{i=1}^{N} r_{ik}}}$$

Find $\frac{\partial Q}{\partial \pi_k}$. The $\pi$'s must satisfy $\sum_{k=1}^K \pi_k = 1$, so this needs a Lagrange multiplier.

$$Q = \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}[\log\pi_k + \log\mathcal{N}(x_i;\mu_k,\Sigma_k)]$$

Remove terms that don't contain $\pi$.

$$Q_\pi = \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}\log\pi_k$$

Add the constraint with a Lagrange multiplier $\lambda$.

$$\mathcal{L} = \sum_{i=1}^{N}\sum_{k=1}^K r_{ik}\log\pi_k + \lambda\left(\sum_{k=1}^K\pi_k - 1\right)$$

Take the derivative w.r.t. $\pi_k$. Only cluster $k$'s terms depend on $\pi_k$, so both sums over clusters collapse to that one term.

$$\frac{\partial\mathcal{L}}{\partial\pi_k} = \sum_{i=1}^{N}\frac{r_{ik}}{\pi_k} + \lambda$$

Set it to zero (first order optimality condition)

$$\sum_{i=1}^{N}\frac{r_{ik}}{\pi_k} + \lambda = 0$$

let $N_k = \sum_{i=1}^N r_{ik}$

$$\frac{N_k}{\pi_k} + \lambda = 0$$

$$\pi_k = -\frac{N_k}{\lambda}$$

Solve for $\lambda$ using the constraint. Sum both sides over $k$.

$$\sum_{k=1}^K\pi_k = -\frac{1}{\lambda}\sum_{k=1}^K N_k$$

$$1 = -\frac{1}{\lambda}\sum_{k=1}^K N_k$$

Each point's responsibilities sum to 1, so $\sum_{k=1}^K N_k = \sum_{i=1}^N\sum_{k=1}^K r_{ik} = N$.

$$1 = -\frac{N}{\lambda}$$

$$\lambda = -N$$

Substitute back.

$$\boxed{\pi_k = \frac{N_k}{N}}$$

# Q2 Exploring Structures of K-Means

## 2.1 Dataset and question (5 points)

Describe:

- the dataset and its source;
- what each observation represents;
- the features you will use;
- any preprocessing or feature scaling;
- why clustering might reveal something interesting about this dataset; and
- one concrete question you hope the clustering analysis will help you investigate.

If the dataset contains known labels, do not use those labels to fit K-means. You may use them later for interpretation.

## 2.1 solution

### Dataset and source

The Seeds dataset from the UCI Machine Learning Repository (<https://archive.ics.uci.edu/dataset/236/seeds>).
Collected at the Institute of Agrophysics, Polish Academy of Sciences, Lublin.
Kernels were imaged with a soft X-ray technique and geometric features were measured from the images.

Charytanowicz, M., Niewczas, J., Kulczycki, P., Kowalski, P. A., Łukasik, S., & Żak, S. (2010). Complete Gradient Clustering Algorithm for Features Analysis of X-ray Images. *Information Technologies in Biomedicine*, Springer.

### What each observation represents

Each row is one wheat kernel.
210 kernels total, 70 each from three varieties: Kama, Rosa, and Canadian.

### Features

All 7 geometric measurements:

| feature | meaning |
|---|---|
| area $A$ | kernel area |
| perimeter $P$ | kernel perimeter |
| compactness $C$ | $4\pi A / P^2$ (1 = perfect circle) |
| length | length of kernel |
| width | width of kernel |
| asymmetry coefficient | how lopsided the kernel is |
| groove length | length of the kernel groove |

The variety label (8th column) is not used to fit K-means, only to interpret the clusters afterwards.

### Preprocessing

No missing values.
The features have different units and scales (area ~10–21, compactness ~0.8–0.92, asymmetry ~0.7–8.5).
K-means uses Euclidean distance, so unscaled, the large-range features would dominate.
Standardize each feature to zero mean and unit variance (z-score).

Caveat: area, perimeter, length, and width are strongly correlated, since they all measure overall size.
After scaling, size still carries more total weight than shape.

### Why clustering might be interesting

The varieties differ in kernel size and shape, but they aren't labeled by measuring.
If the geometric measurements alone form natural groups, variety is physically visible in kernel shape, which is useful for automated grain sorting.
If the groups overlap, it shows which varieties look alike.

### Question

Without using the variety labels, does K-means with $K = 3$ recover the three wheat varieties from kernel geometry alone?
If not, which varieties get confused, and is the separation driven by size or by shape (compactness and asymmetry)?

## 2.2 Implement K-means from scratch (12 points)

Implement K-means yourself. Your implementation must include, at minimum:

- initialization of centroids;
- assignment of points to the closest centroid;
- centroid updates;
- a stopping criterion; and
- a maximum number of iterations.

You may use numpy, but you may not call a library K-means implementation for this section.

Briefly describe how you handle edge cases such as empty clusters.

## 2.2 solution

Code is in `Assignment4_starter.py` (`update_assignments`, `update_centroids`, `kmeans`).

- Initialization: pick $k$ distinct random data points as the starting centroids.
- Assignment: compute the squared distance from every point to every centroid, assign each point to the closest one.
- Update: each centroid becomes the mean of the points assigned to it.
- Stopping: stop when no centroid coordinate moves more than `tol` (default $10^{-6}$).
- Max iterations: stop after `max_iterations` (default 100) even if not converged.

Empty clusters: if a cluster gets no points, its centroid is restarted at a random data point.


## 2.3 Choosing and interpreting $K$ (10 points)

Evaluate at least four different values of $K$.

Use at least one quantitative diagnostic, such as:

- within-cluster sum of squares;
- silhouette score;
- stability across random initializations; or
- another metric you justify.

Then choose a value (or range of values) of $K$ that you believe is most informative for your dataset.

Your choice does not need to correspond to the numerically best metric value if you can justify why another solution is more useful or interpretable.

## 2.3 solution

Code is in `q2_3.py`.

Tried $K = 2, \ldots, 7$ on the standardized data.
For each $K$, ran K-means from 20 random initializations and kept the run with the lowest WCSS.

Three diagnostics:

- WCSS: within-cluster sum of squares (lower is tighter, but always drops as $K$ grows).
- Silhouette: how much closer each point is to its own cluster than the next one (-1 to 1, higher is better).
- Stability: average adjusted Rand index between every pair of the 20 runs (1 = every run gives the same clustering).

| $K$ | WCSS | silhouette | stability |
|---|---|---|---|
| 2 | 659.2 | 0.466 | 0.973 |
| 3 | 430.7 | 0.401 | 0.932 |
| 4 | 371.4 | 0.328 | 0.686 |
| 5 | 326.8 | 0.284 | 0.615 |
| 6 | 289.1 | 0.288 | 0.596 |
| 7 | 262.3 | 0.276 | 0.556 |

![choosing K](q2_3_choose_k.png)

### $K = 3$

- WCSS has a clear elbow at 3: going 2 → 3 drops it by 229, but 3 → 4 only drops it by 59.
- Stability stays high through $K = 3$ (0.93), then falls off at $K = 4$ (0.69). Past 3, the clusters depend on the random start, so they're not real structure.
- Silhouette is best at $K = 2$, not 3.


## 2.4 Visualization and analysis (8 points)

Create at least one visualization that helps explain the clusters. If your data are higher-dimensional, you may use PCA or another dimensionality-reduction method for visualization only.

Discuss:

- what distinguishes the clusters;
- whether the clustering supports your original question;
- whether some points appear ambiguous or poorly represented by hard cluster assignments; and
- at least one limitation of applying K-means to this dataset.

## 2.4 solution

Code is in `q2_4.py`.
K-means with $K = 3$ (best of 20 runs), projected to 2D with PCA for plotting only.
PC1 and PC2 explain 72% and 17% of the variance.

![clusters](q2_4_clusters.png)

Left: K-means clusters. Circled points are ambiguous (see below).
Right: same points colored by true variety.

### What distinguishes the clusters

Cluster means in original units:

| cluster | area | perimeter | compactness | length | width | asymmetry | groove |
|---|---|---|---|---|---|---|---|
| 0 (mostly Kama) | 14.44 | 14.34 | 0.88 | 5.51 | 3.26 | 2.71 | 5.12 |
| 1 (mostly Rosa) | 18.50 | 16.20 | 0.88 | 6.18 | 3.70 | 3.63 | 6.04 |
| 2 (mostly Canadian) | 11.86 | 13.25 | 0.85 | 5.23 | 2.85 | 4.74 | 5.10 |

- Size is the main split. Cluster 1 is big kernels, cluster 2 is small, cluster 0 is in between. This is PC1 in the plot.
- Shape separates cluster 2 further: lowest compactness (less round) and highest asymmetry.
- Cluster 0 has the lowest asymmetry.

### Does it support the question?

Mostly yes. Without labels, K-means recovers the three varieties from geometry alone: 193 of 210 kernels (92%) land in their variety's cluster.
Rosa is the cleanest (big kernels). The confusion is mostly Kama getting mixed with the other two, since Kama sits in the middle on size.
So separation is driven mainly by size, with shape (compactness, asymmetry) helping split Kama from Canadian.

### Ambiguous points

Called a point ambiguous if its distance to the closest centroid is more than 0.8 times its distance to the second-closest.
29 of 210 points are ambiguous (circled).
They sit on the boundaries between clusters, mostly around the Kama cluster, which is where the misassigned points are too.
Hard assignment forces these into one cluster with full confidence, even though they're nearly halfway between two. A soft method like a GMM would give them split responsibilities instead.

### Limitation

K-means assumes round, equal-size clusters, since it only uses Euclidean distance to the centroid.
Here the clusters aren't round: the Rosa and Canadian groups are stretched out (see the plot), and the size features are strongly correlated, so size gets counted several times.
A GMM with full covariances could fit stretched clusters better.


# Part 3 Classification with Noisy Labels (45 points)

Choose a supervised classification dataset of your own. This may be the same dataset as Part 2 if it contains an appropriate target label, or a different dataset.

Your task is to investigate how label noise affects a classifier and whether a data-driven strategy can reduce the damage.

## 3.1 Baseline problem and evaluation design (8 points)

Describe:

- the prediction task;
- the target classes;
- the features;
- your train/validation/test split; and
- the metric(s) you will use.

Train a baseline classifier on the clean training data. Use an SVM with either a linear or RBF kernel unless you have a strong reason to choose another kernel.

Tune hyperparameters using only the training/validation data. Do not tune on the test set.

## 3.1 solution

Code is in `q3_1.py`.

- Task: predict a wheat kernel's variety from its geometry. Same Seeds dataset as Part 2.
- Classes: Kama, Rosa, Canadian (70 each, balanced).
- Features: the same 7 geometric measurements, standardized. The scaler is fit on the training set only.
- Split: 60/20/20 train/validation/test (126/42/42), stratified so each split has equal class counts. Fixed random seed.
- Metrics: accuracy, and macro F1 (average F1 over the 3 classes, so every class counts equally).

Baseline: RBF-kernel SVM.
Tuned $C \in \{0.1, 1, 10, 100\}$ and $\gamma \in \{0.01, 0.1, 1, 10\}$ by training on train and scoring macro F1 on validation.
Best: $C = 10$, $\gamma = 1$ (validation macro F1 = 0.976).
Then evaluated once on test.

| | accuracy | macro F1 |
|---|---|---|
| validation | 0.976 | 0.976 |
| test | 0.857 | 0.851 |

The gap between validation and test has two causes.
Each set is only 42 points, so one misclassified kernel moves accuracy by about 2.4%.
Also, the validation score is optimistic because it's the best of 16 settings picked on that same set.

## 3.2 Introduce label noise (8 points)

Create at least two noisy-label settings. At least one setting should use asymmetric or class-dependent noise rather than flipping every label with the same probability.

Explain why your noise model is reasonable as an experimental stress test.

For multiclass datasets, define clearly how corrupted labels are selected.

Train the same classifier on the noisy training data and compare performance with the clean-data baseline.

Because label corruption is random, repeat each noisy experiment with multiple random seeds and report a mean and a measure of variability.

## 3.2 solution

Code is in `q3_2.py`, noise function is `corrupt_labels` in `Assignment4_starter.py`.

Only the training labels are corrupted. Test labels stay clean, so the test score measures how well the model learned the real classes.

### Noise settings

- Symmetric (rate $p$): pick exactly $\text{round}(p \cdot n)$ training points at random, change each one's label to one of the other two classes, chosen uniformly. Used $p = 0.2$ and $0.4$ (25 and 50 of 126 labels).
- Asymmetric, Kama → Canadian (rate $p$): pick exactly $\text{round}(p \cdot n_{\text{Kama}})$ of the Kama training points at random and relabel them Canadian. Rosa and Canadian labels are untouched. Used $p = 0.3$ and $0.6$ (13 and 25 of 42 Kama labels).

### Why these are reasonable

- Symmetric noise models careless mistakes, like typos when recording labels, where any wrong class is equally likely.
- The asymmetric noise models a person sorting kernels by eye. Part 2 showed Kama sits between the other two varieties in size, and the Kama/Canadian boundary is where K-means got confused. Mistaking a small Kama kernel for Canadian is the kind of error that would actually happen. Going one direction only also makes it a harder test, because the errors are consistent instead of spread out.

### Results

Same SVM as the baseline ($C = 10$, $\gamma = 1$, not re-tuned). 10 seeds per setting, mean ± standard deviation on the clean test set.

| setting | wrong labels | accuracy | macro F1 |
|---|---|---|---|
| clean (baseline) | 0 | 0.857 | 0.851 |
| symmetric 20% | 25 | 0.707 ± 0.053 | 0.701 ± 0.055 |
| symmetric 40% | 50 | 0.586 ± 0.062 | 0.582 ± 0.065 |
| Kama → Canadian 30% | 13 | 0.798 ± 0.042 | 0.774 ± 0.054 |
| Kama → Canadian 60% | 25 | 0.743 ± 0.046 | 0.688 ± 0.071 |

- All noise hurts, and more noise hurts more.
- Symmetric 40% loses almost 30 points of accuracy.
- Symmetric 20% and Kama → Canadian 60% have the same number of wrong labels (25). The asymmetric one keeps higher accuracy, but macro F1 drops about as much. That's because the damage is concentrated on one class: per-class recall is Kama 0.26, Rosa 1.00, Canadian 0.97.
Kama gets squeezed out by Canadian, while the other two are basically unaffected.
For comparison, symmetric 20% spreads the damage: Kama 0.59, Rosa 0.83, Canadian 0.71.
- Variability across seeds is around ±5 points, so which labels get flipped matters a lot on a dataset this small.


## 3.3 Design a label-repair or noise-robustness strategy (15 points)

Design and evaluate one method intended to identify, correct, down-weight, or otherwise reduce the effect of noisy labels.

Your method must use one of the ideas below:

- nearest neighbors;
- clustering, such as K-means or a Gaussian mixture model; or
- a combination of the two.

You have substantial freedom in how you formulate the method. For example, you might:

- relabel examples whose labels strongly disagree with their neighbors;
- remove examples with low neighborhood agreement;
- identify clusters with internally inconsistent labels;
- use soft cluster membership to estimate label confidence; or
- combine local and global information.

The important part is that you explain your reasoning and make the method precise enough to reproduce.

## 3.3 solution

Code is in `q3_3.py`, method is `repair_labels` in `Assignment4_starter.py`.

### Method: nearest-neighbor relabeling

For each training point $i$:

1. Find its $k = 10$ nearest neighbors in the standardized feature space (Euclidean distance, not counting $i$ itself).
2. Find the most common label among those neighbors, and how many neighbors have it.
3. If that label is different from $i$'s label and at least $7$ of the $10$ neighbors have it, change $i$'s label to it.

All decisions use the original noisy labels, so the result doesn't depend on the order points are processed in.
Then train the same SVM ($C = 10$, $\gamma = 1$) on the repaired labels and test on the clean test set.

$k = 10$ and the 70% threshold were picked up front and not tuned. Tuning them would need clean validation labels, which you wouldn't have in a real noisy-label problem.

### Reasoning

Part 2 showed the varieties form fairly tight groups in feature space (92% agreement with K-means).
So a point's true label is usually the same as its neighbors'.
A randomly flipped label sticks out as a point whose label disagrees with almost everything around it.
The 70% threshold means it only relabels when the neighbors clearly agree, so points near real class boundaries (where neighbors are mixed) are left alone.

### Results

10 seeds per setting, same noisy labels as 3.2. "Wrong labels" is counted against the true training labels.

| setting | wrong labels before → after | accuracy noisy | accuracy repaired | macro F1 noisy | macro F1 repaired |
|---|---|---|---|---|---|
| clean | 0 → 6 | 0.857 | 0.881 | 0.851 | 0.879 |
| symmetric 20% | 25 → 10 | 0.707 ± 0.053 | 0.838 ± 0.035 | 0.701 ± 0.055 | 0.838 ± 0.034 |
| symmetric 40% | 50 → 34.4 | 0.586 ± 0.062 | 0.679 ± 0.079 | 0.582 ± 0.065 | 0.670 ± 0.088 |
| Kama → Canadian 30% | 13 → 10.7 | 0.798 ± 0.042 | 0.836 ± 0.022 | 0.774 ± 0.054 | 0.823 ± 0.027 |
| Kama → Canadian 60% | 25 → 34.1 | 0.743 ± 0.046 | 0.702 ± 0.048 | 0.688 ± 0.071 | 0.616 ± 0.077 |

- Symmetric 20%: works best here. Fixes 60% of the bad labels and gets almost back to the clean baseline (0.838 vs 0.857).
- Symmetric 40%: still helps, but less. With 40% noise, many neighborhoods are themselves too noisy to agree.
- Kama → Canadian 30%: small improvement. Only fixes about 2 of the 13 bad labels, but it also lowers the variability across seeds.
- Kama → Canadian 60%: makes it worse. Most Kama points are now labeled Canadian, so the neighbors of a correctly-labeled Kama point mostly say "Canadian" and the method flips it to the wrong label. Neighbor voting assumes the noise is a minority in each neighborhood, and consistent one-directional noise breaks that.
- Clean data: it changes 6 correct labels (outlier points that sit inside another class's region), but test accuracy actually goes up slightly. Smoothing the labels this way acts a bit like regularization.

## 3.4 Controlled comparison (8 points)

Compare at least these three conditions:

- classifier trained on clean training labels;
- classifier trained on noisy training labels; and
- classifier trained after applying your repair/robustness strategy.

Use the same clean test set for all conditions.

Present your results in a clear table or figure and discuss whether your method helps consistently or only in certain noise regimes.

## 3.4 solution

Code is in `q3_4.py`.
Same SVM ($C = 10$, $\gamma = 1$), same split, same clean test set for every condition. Noisy and repaired are mean ± std over 10 seeds.

Test macro F1:

| noise setting | clean | noisy | repaired |
|---|---|---|---|
| symmetric 20% | 0.851 | 0.701 ± 0.055 | **0.838 ± 0.034** |
| symmetric 40% | 0.851 | 0.582 ± 0.065 | **0.670 ± 0.088** |
| Kama → Canadian 30% | 0.851 | 0.774 ± 0.054 | **0.823 ± 0.027** |
| Kama → Canadian 60% | 0.851 | **0.688 ± 0.071** | 0.616 ± 0.077 |

![comparison](q3_4_comparison.png)

Accuracy shows the same pattern (see the table in 3.3).

The method doesn't help consistently. It depends on the noise regime:

- Helps a lot with low symmetric noise: nearly back to clean.
- Helps some with high symmetric noise and with mild asymmetric noise.
- Hurts with heavy asymmetric noise, where the wrong label becomes the majority among Kama points.

So it works when the noise is a minority in each neighborhood and fails when it isn't.

## 3.5 Reflection (6 points)

In approximately 1–2 paragraphs, answer:

- When did your strategy help?
- When did it fail or make things worse?
- What assumptions does your approach make about the geometry of the data or the relationship between features and labels?
- If this were a real-world dataset with unknown label errors, what evidence would you need before automatically changing labels?

## 3.5 solution

The neighbor relabeling helped most when the noise was random and not too heavy (symmetric 20%), where it fixed most of the bad labels and almost matched the clean baseline. It still helped at symmetric 40% and Kama → Canadian 30%, just less. It made things worse at Kama → Canadian 60%: once most Kama points were labeled Canadian, the neighbors of the correctly labeled Kama points voted "Canadian" too, so the method flipped good labels to bad ones. It also changed a few correct labels even on clean data, which happened not to hurt here but could in another dataset.

The method assumes points that are close in feature space have the same label: classes form compact groups, the scaled Euclidean distance is a meaningful similarity, and within any neighborhood the wrong labels are a minority. Seeds fits this pretty well since the varieties mostly separate by size and shape, but it breaks for systematic noise (one class consistently mislabeled as another), near real class boundaries, and for small or rare classes that are naturally outvoted by a bigger neighbor. On a real dataset with unknown errors, I wouldn't change labels automatically without more evidence: a small hand-checked subset to measure how often the flagged labels are actually wrong, a check that the flagged points aren't concentrated in one class (a sign of systematic noise or a real minority class), and agreement from a second independent method (e.g. a GMM's soft membership, or a classifier's cross-validated predictions). Even then, it's safer to flag or down-weight suspicious labels for review than to silently overwrite them.
