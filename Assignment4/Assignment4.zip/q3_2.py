import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

from Assignment4_starter import corrupt_labels

# same data, split, and scaling as 3.1
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00236/seeds_dataset.txt"
seeds = pd.read_csv(url, sep=r"\s+", header=None)
X = seeds.iloc[:, 0:7].to_numpy()
y = seeds[7].to_numpy()  # 1=Kama, 2=Rosa, 3=Canadian

X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4, stratify=y, random_state=0)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=0)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# same classifier as the 3.1 baseline
C = 10
gamma = 1

settings = [
    ("clean", None),
    ("symmetric 20%", {"type": "symmetric", "rate": 0.2}),
    ("symmetric 40%", {"type": "symmetric", "rate": 0.4}),
    ("Kama -> Canadian 30%", {"type": "asymmetric", "rate": 0.3, "from": 1, "to": 3}),
    ("Kama -> Canadian 60%", {"type": "asymmetric", "rate": 0.6, "from": 1, "to": 3}),
]
n_seeds = 10

print("setting                 accuracy (mean +- std)   macro F1 (mean +- std)")
for name, config in settings:
    accuracies = []
    f1s = []
    for seed in range(n_seeds):
        if config is None:
            y_train_used = y_train
        else:
            y_train_used = corrupt_labels(y_train, config, random_state=seed)

        model = SVC(kernel="rbf", C=C, gamma=gamma)
        model.fit(X_train, y_train_used)
        y_pred = model.predict(X_test)  # test labels are always clean
        accuracies.append(accuracy_score(y_test, y_pred))
        f1s.append(f1_score(y_test, y_pred, average="macro"))

    print(name.ljust(24),
          round(np.mean(accuracies), 3), "+-", round(np.std(accuracies), 3), "        ",
          round(np.mean(f1s), 3), "+-", round(np.std(f1s), 3))
