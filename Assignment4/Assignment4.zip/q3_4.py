import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import f1_score

from Assignment4_starter import corrupt_labels, repair_labels

# same data, split, and scaling as 3.1
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00236/seeds_dataset.txt"
seeds = pd.read_csv(url, sep=r"\s+", header=None)
X = seeds.iloc[:, 0:7].to_numpy()
y = seeds[7].to_numpy()

X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.4, stratify=y, random_state=0)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=0)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


def test_f1(y_train_used):
    model = SVC(kernel="rbf", C=10, gamma=1)
    model.fit(X_train, y_train_used)
    return f1_score(y_test, model.predict(X_test), average="macro")


clean_f1 = test_f1(y_train)

settings = [
    ("sym 20%", {"type": "symmetric", "rate": 0.2}),
    ("sym 40%", {"type": "symmetric", "rate": 0.4}),
    ("K->C 30%", {"type": "asymmetric", "rate": 0.3, "from": 1, "to": 3}),
    ("K->C 60%", {"type": "asymmetric", "rate": 0.6, "from": 1, "to": 3}),
]

names = []
noisy_mean = []
noisy_std = []
repaired_mean = []
repaired_std = []
for name, config in settings:
    noisy = []
    repaired = []
    for seed in range(10):
        y_noisy = corrupt_labels(y_train, config, random_state=seed)
        noisy.append(test_f1(y_noisy))
        repaired.append(test_f1(repair_labels(X_train, y_noisy, k=10, threshold=0.7)))
    names.append(name)
    noisy_mean.append(np.mean(noisy))
    noisy_std.append(np.std(noisy))
    repaired_mean.append(np.mean(repaired))
    repaired_std.append(np.std(repaired))

positions = np.arange(len(names))
plt.figure(figsize=(7, 4))
plt.bar(positions - 0.2, noisy_mean, 0.4, yerr=noisy_std, capsize=4, label="noisy")
plt.bar(positions + 0.2, repaired_mean, 0.4, yerr=repaired_std, capsize=4, label="repaired")
plt.axhline(clean_f1, color="black", linestyle="--", label="clean baseline")
plt.xticks(positions, names)
plt.ylabel("test macro F1")
plt.ylim(0.4, 1.0)
plt.legend()
plt.tight_layout()
plt.savefig("q3_4_comparison.png", dpi=150)
