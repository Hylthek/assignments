"""Optional starter code for CSE 242 Assignment 4.

You do not need to use this file. Add, remove, or reorganize functions as useful.
"""

import numpy as np


def update_assignments(X, centroids):
    """Return the index of the closest centroid for each observation."""
    k = centroids.shape[0]
    distances = np.zeros((X.shape[0], k))
    for j in range(k):
        distances[:, j] = np.sum((X - centroids[j]) ** 2, axis=1)
    return np.argmin(distances, axis=1)


def update_centroids(X, assignments, k, rng):
    """Return updated centroids for k clusters."""
    centroids = np.zeros((k, X.shape[1]))
    for j in range(k):
        points = X[assignments == j]
        if len(points) == 0:
            # empty cluster: restart it at a random data point
            centroids[j] = X[rng.integers(X.shape[0])]
        else:
            centroids[j] = np.mean(points, axis=0)
    return centroids


def kmeans(X, k, max_iterations=100, tol=1e-6, random_state=None):
    """Fit K-means from scratch and return centroids, assignments, and inertia."""
    rng = np.random.default_rng(random_state)

    # initialize: k distinct random data points
    centroids = X[rng.choice(X.shape[0], size=k, replace=False)]

    for iteration in range(max_iterations):
        assignments = update_assignments(X, centroids)
        new_centroids = update_centroids(X, assignments, k, rng)
        shift = np.max(np.abs(new_centroids - centroids))
        centroids = new_centroids
        if shift < tol:
            break

    assignments = update_assignments(X, centroids)
    inertia = np.sum((X - centroids[assignments]) ** 2)
    return centroids, assignments, inertia


def corrupt_labels(y, noise_config, random_state=None):
    """Create a reproducible noisy version of y according to your design.

    noise_config examples:
      {"type": "symmetric", "rate": 0.2}
          exactly round(rate * n) labels, picked at random, are each changed
          to one of the other classes, chosen uniformly.
      {"type": "asymmetric", "rate": 0.3, "from": 1, "to": 3}
          exactly round(rate * n_from) labels of class "from", picked at
          random, are changed to class "to". Other classes are untouched.
    """
    rng = np.random.default_rng(random_state)
    y_noisy = y.copy()
    classes = np.unique(y)

    if noise_config["type"] == "symmetric":
        n_flip = int(round(noise_config["rate"] * len(y)))
        flip_indices = rng.choice(len(y), size=n_flip, replace=False)
        for i in flip_indices:
            other_classes = classes[classes != y[i]]
            y_noisy[i] = rng.choice(other_classes)

    if noise_config["type"] == "asymmetric":
        source_indices = np.where(y == noise_config["from"])[0]
        n_flip = int(round(noise_config["rate"] * len(source_indices)))
        flip_indices = rng.choice(source_indices, size=n_flip, replace=False)
        for i in flip_indices:
            y_noisy[i] = noise_config["to"]

    return y_noisy


def repair_labels(X, y_noisy, k=10, threshold=0.7):
    """Nearest-neighbor label repair.

    For each training point, look at its k nearest neighbors (not counting
    itself). If at least threshold * k of them share one label, and that
    label is different from the point's own label, change the point's label
    to it. All decisions use the original noisy labels, so the order of
    points doesn't matter.
    """
    n = X.shape[0]
    y_repaired = y_noisy.copy()
    for i in range(n):
        distances = np.sum((X - X[i]) ** 2, axis=1)
        distances[i] = np.inf  # don't count the point itself
        neighbors = np.argsort(distances)[:k]
        neighbor_labels = y_noisy[neighbors]

        labels, counts = np.unique(neighbor_labels, return_counts=True)
        top_label = labels[np.argmax(counts)]
        top_count = np.max(counts)

        if top_label != y_noisy[i] and top_count >= threshold * k:
            y_repaired[i] = top_label
    return y_repaired
